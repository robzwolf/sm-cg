# Software Methodologies – Computer Graphics (WebGL) Assignment
Using WebGL programming, implement a program to render a 3D classroom.

## To Run
1) Start a local Python server in the `classroom/` directory:

    python3 -m http.server 8001


2) Navigate to `http://localhost:8001` in your browser.

## Comments
The webpage can take a few seconds to load, please be patient.

## Author
vzbf32